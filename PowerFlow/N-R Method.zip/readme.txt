1. This folder contains 5 files..
          1. nrlfppg.m
          2. loadflow.m
          3. ybusppg.m
          4. busdatas.m
          5. linedatasm
          6. pol2rect.m

2. Keep all the files in the same directory..

3. The main program is nrlfppg.m..

4. Bus number 1 is assumed to be the slack bus..

5. There may be mistakes in the program. If anyone finds out any mistake, please let me know....